const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");
if (!ctx) {
  console.error("Canvas context is not available");
}

canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

const playerSpriteSheets = {
  idle: new Image(),
  run: new Image(),
  jump: new Image(),
};

// Set up onLoad event for all images
let imagesLoaded = 0;
const totalImages = 3;

function checkImagesLoaded() {
  imagesLoaded++;
  if (imagesLoaded === totalImages) {
    gameState = "start";  // Start the game when all images are loaded
    gameLoop();
  }
}

playerSpriteSheets.idle.src = "image/64x64/idle.png";
playerSpriteSheets.idle.onload = checkImagesLoaded;
playerSpriteSheets.run.src = "image/64x64/run.png";
playerSpriteSheets.run.onload = checkImagesLoaded;
playerSpriteSheets.jump.src = "image/64x64/jump.png";
playerSpriteSheets.jump.onload = checkImagesLoaded;

const animationSettings = {
  idle: { width: 64, height: 64, totalFrames: 7 },
  run: { width: 64, height: 64, totalFrames: 7 },
  jump: { width: 64, height: 64, totalFrames: 7 },
};

playerSpriteSheets.idle.onload = () => { console.log('Idle sprite loaded'); };
playerSpriteSheets.run.onload = () => { console.log('Run sprite loaded'); };
playerSpriteSheets.jump.onload = () => { console.log('Jump sprite loaded'); };

let currentAnimation = "idle";  // Initial animation
let currentFrame = 0;  // Start with the first frame
let facingRight = true;

// Player settings
const player = {
  x: 100,
  y: canvas.height - 100,
  width: 64,
  height: 64,
  speed: 5,
  dx: 0,
  dy: 0,
  gravity: 0.5,
  jumpPower: -18,
  grounded: false,
};

// Platform data
let platforms = [
  { x: 0, y: canvas.height - 30, width: canvas.width, height: 30 },
  { x: 150, y: 400, width: 200, height: 20 },
  { x: 400, y: 300, width: 200, height: 20 },
  { x: 600, y: 200, width: 100, height: 20 },
];

// Camera settings
const camera = { x: 0, y: 0, width: canvas.width, height: canvas.height };

// Score
let score = 0;

// Game states
let gameState = "start"; // Possible states: start, playing, paused, over

document.addEventListener("keydown", (e) => {
  if (e.key === "Enter" && gameState === "start") {
    gameState = "playing";
    gameLoop();  // Start the game loop
  }
});

// Input handling
let leftPressed = false;
let rightPressed = false;

document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a") leftPressed = true;
  if (e.key === "ArrowRight" || e.key === "d") rightPressed = true;
  if (e.key === " " && player.grounded) {
    player.dy = player.jumpPower;
    player.grounded = false;
  }
  if (e.key === "Enter" && gameState === "start") {
    gameState = "playing";
    gameLoop();
  } else if (e.key === "Escape") {
    gameState = gameState === "playing" ? "paused" : "playing";
    if (gameState === "playing") gameLoop();
  }
});

document.addEventListener("keyup", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a") leftPressed = false;
  if (e.key === "ArrowRight" || e.key === "d") rightPressed = false;
});

// Functions
function handlePlayerMovement() {
  if (leftPressed) {
    player.dx = -player.speed;
    facingRight = false;
  } else if (rightPressed) {
    player.dx = player.speed;
    facingRight = true;
  } else {
    player.dx = 0;
  }
}

function updatePlayer() {
  player.x += player.dx;
  player.y += player.dy;

  if (!player.grounded) {
    player.dy += player.gravity;
  }

  // Horizontal boundary constraints
  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width)
    player.x = canvas.width - player.width;

  // Vertical boundary constraints
  if (player.y + player.height > canvas.height) {
    player.y = canvas.height - player.height;
    player.dy = 0;
    player.grounded = true;
  }
}

function checkPlatformCollision() {
  player.grounded = false;
  platforms.forEach((platform) => {
    // Downward collision
    if (
      player.dy > 0 &&
      player.y + player.height <= platform.y &&
      player.y + player.height + player.dy >= platform.y &&
      player.x + player.width > platform.x &&
      player.x < platform.x + platform.width
    ) {
      player.y = platform.y - player.height;
      player.dy = 0;
      player.grounded = true;
    }
    // Horizontal collision
    if (
      player.x + player.width > platform.x &&
      player.x < platform.x + platform.width &&
      player.y + player.height > platform.y &&
      player.y < platform.y + platform.height
    ) {
      if (player.dx > 0) player.x = platform.x - player.width;
      if (player.dx < 0) player.x = platform.x + platform.width;
    }
  });
}

function updateAnimation() {
  // Change animation based on player's state
  let newAnimation = "idle";

  if (player.dy !== 0) {
    newAnimation = "jump"; // Player is jumping
  } else if (player.dx !== 0) {
    newAnimation = "run"; // Player is running
  }

  // Only reset the frame when the animation changes
  if (newAnimation !== currentAnimation) {
    currentAnimation = newAnimation;
    currentFrame = 0;  // Reset to the first frame of the new animation
  }

  // Update the frame for the current animation
  currentFrame = (currentFrame + 1) % animationSettings[currentAnimation].totalFrames;
}


function drawPlayer() {
  const animation = animationSettings[currentAnimation];
  ctx.save();

  if (!facingRight && currentAnimation === "run") {
    ctx.scale(-1, 1);
    ctx.drawImage(
      playerSpriteSheets[currentAnimation],
      currentFrame * animation.width,
      0,
      animation.width,
      animation.height,
      -player.x - player.width,
      player.y,
      player.width,
      player.height
    );
  } else {
    ctx.drawImage(
      playerSpriteSheets[currentAnimation],
      currentFrame * animation.width,
      0,
      animation.width,
      animation.height,
      player.x,
      player.y,
      player.width,
      player.height
    );
  }

  ctx.restore();
  console.log(`Player Position: ${player.x}, ${player.y}`);
  console.log(`Current Frame: ${currentFrame}`);
}

function drawPlatforms() {
  ctx.fillStyle = "brown";
  platforms.forEach((platform) => {
    ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
  });
}

function updateScore() {
  ctx.font = "20px Arial";
  ctx.fillStyle = "black";
  ctx.fillText(`Score: ${score}`, 10, 30);
}

function renderGameOver() {
  ctx.font = "30px Arial";
  ctx.fillStyle = "red";
  ctx.fillText("Game Over", canvas.width / 2 - 75, canvas.height / 2);
}

function renderWin() {
  ctx.font = "30px Arial";
  ctx.fillStyle = "green";
  ctx.fillText("You Win!", canvas.width / 2 - 75, canvas.height / 2);
}

function gameLoop() {
  // Only run the loop if the game is in the "playing" state
  if (gameState !== "playing") return;

  // Clear the canvas to prepare for the new frame
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Handle player movement and physics
  handlePlayerMovement();
  updatePlayer();
  checkPlatformCollision();

  // Update player animation
  updateAnimation();

  // Draw player, platforms, and score
  drawPlayer();
  drawPlatforms();
  updateScore();

  // Check if the player has fallen off the screen (game over)
  if (player.y > canvas.height) {
    gameState = "over";
    renderGameOver();
    return;
  }

  // Check if the player has reached the top (win condition)
  if (player.y <= -300) {
    gameState = "over";
    renderWin();
    return;
  }

  // Keep calling the game loop on the next available frame
  requestAnimationFrame(gameLoop);
}

console.log(`Canvas Width: ${canvas.width}, Canvas Height: ${canvas.height}`);