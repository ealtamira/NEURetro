const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

// Set canvas size
canvas.width = window.innerWidth;
canvas.height = window.innerHeight;

// Makes Player

//Player Sprite; Create an image object for the player sprite
const playerSprite = new Image();
playerSprite.src = "image/64x64/idle.png"; // Path to the sprite image

const player = {
  x: 100,
  y: canvas.height - 100,
  width: 64, // Adjust size based on your sprite dimensions
  height: 64, // Adjust size based on your sprite dimensions
  speed: 5,
  dx: 0, // horizontal velocity
  dy: 0, // vertical velocity
  gravity: 0.5,
  jumpPower: -15,
  grounded: false,
};

// Animation
const playerSpriteSheet = new Image();
playerSpriteSheet.src = "image/64x64/run.png"; // Sprite sheet with multiple frames

const playerSpriteWidth = 64; // Width of each frame in the sprite sheet
const playerSpriteHeight = 64; // Height of each frame

let currentFrame = 0; // Current frame to draw

function drawPlayer() {
  // Determine which frame to draw based on player movement
  ctx.drawImage(
    playerSpriteSheet,
    currentFrame * playerSpriteWidth, // X position of the frame on the sprite sheet
    0, // Y position of the frame on the sprite sheet
    playerSpriteWidth,
    playerSpriteHeight,
    player.x,
    player.y,
    player.width,
    player.height
  );
}

function updateAnimation() {
  // Update the current frame (loop through 0 to 3 for a 4-frame animation)
  currentFrame = (currentFrame + 1) % 4; // 4 frames in the sprite sheet
}

// Update player position based on velocity
function updatePlayer() {
  player.x += player.dx;
  player.y += player.dy;

  // Apply gravity
  if (!player.grounded) {
    player.dy += player.gravity;
  }

  // Keep player within canvas bounds
  if (player.x < 0) player.x = 0;
  if (player.x + player.width > canvas.width)
    player.x = canvas.width - player.width;
  if (player.y + player.height > canvas.height) {
    player.y = canvas.height - player.height;
    player.dy = 0; // stop falling
    player.grounded = true; // player is on the ground
  }
}

//Input Handling
let leftPressed = false;
let rightPressed = false;
let upPressed = false;

// Handle keyboard input
document.addEventListener("keydown", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a") leftPressed = true;
  if (e.key === "ArrowRight" || e.key === "d") rightPressed = true;
  if (e.key === " " && player.grounded) {
    // Jump when space is pressed
    player.dy = player.jumpPower;
    player.grounded = false;
  }
});

document.addEventListener("keyup", (e) => {
  if (e.key === "ArrowLeft" || e.key === "a") leftPressed = false;
  if (e.key === "ArrowRight" || e.key === "d") rightPressed = false;
});

// Update player movement based on input
function handlePlayerMovement() {
  if (leftPressed) player.dx = -player.speed;
  else if (rightPressed) player.dx = player.speed;
  else player.dx = 0;
}

//Collision and Platforms
const platforms = [
  { x: 0, y: canvas.height - 30, width: canvas.width, height: 30 },
  { x: 150, y: 400, width: 200, height: 20 },
  { x: 400, y: 300, width: 200, height: 20 },
];

// Draw platforms
function drawPlatforms() {
  ctx.fillStyle = "green";
  platforms.forEach((platform) => {
    ctx.fillRect(platform.x, platform.y, platform.width, platform.height);
  });
}

// Check if player is colliding with a platform
function checkPlatformCollision() {
  platforms.forEach((platform) => {
    if (
      player.y + player.height <= platform.y &&
      player.y + player.height + player.dy >= platform.y &&
      player.x + player.width > platform.x &&
      player.x < platform.x + platform.width
    ) {
      player.y = platform.y - player.height;
      player.dy = 0;
      player.grounded = true;
    }
  });
}

//Run Game
function gameLoop() {
  ctx.clearRect(0, 0, canvas.width, canvas.height); // Clear the canvas on each frame

  // Handle player movement
  handlePlayerMovement();
  updatePlayer();
  checkPlatformCollision();

  // Update animation (for walking or idle)
  updateAnimation();

  // Draw game elements
  drawPlatforms();
  drawPlayer(); // Draw player with the sprite

  // Repeat the game loop
  requestAnimationFrame(gameLoop);
}

// gameLoop(); // start the game loop

playerSprite.onload = function () {
  // The image has loaded, start the game loop
  gameLoop();
};